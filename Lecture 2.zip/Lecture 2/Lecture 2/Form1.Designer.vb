﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.firstnumlbl = New System.Windows.Forms.Label()
        Me.secondnumlbl = New System.Windows.Forms.Label()
        Me.answer = New System.Windows.Forms.Label()
        Me.firstnumtxt = New System.Windows.Forms.TextBox()
        Me.secondnumtxt = New System.Windows.Forms.TextBox()
        Me.answertxt = New System.Windows.Forms.TextBox()
        Me.sumbtn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(136, 453)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(318, 103)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Calculator"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'firstnumlbl
        '
        Me.firstnumlbl.AutoSize = True
        Me.firstnumlbl.Location = New System.Drawing.Point(10, 111)
        Me.firstnumlbl.Name = "firstnumlbl"
        Me.firstnumlbl.Size = New System.Drawing.Size(96, 20)
        Me.firstnumlbl.TabIndex = 1
        Me.firstnumlbl.Text = "FirstNumber"
        '
        'secondnumlbl
        '
        Me.secondnumlbl.AutoSize = True
        Me.secondnumlbl.Location = New System.Drawing.Point(10, 162)
        Me.secondnumlbl.Name = "secondnumlbl"
        Me.secondnumlbl.Size = New System.Drawing.Size(120, 20)
        Me.secondnumlbl.TabIndex = 2
        Me.secondnumlbl.Text = "SecondNumber"
        '
        'answer
        '
        Me.answer.AutoSize = True
        Me.answer.Location = New System.Drawing.Point(19, 341)
        Me.answer.Name = "answer"
        Me.answer.Size = New System.Drawing.Size(62, 20)
        Me.answer.TabIndex = 3
        Me.answer.Text = "Answer"
        '
        'firstnumtxt
        '
        Me.firstnumtxt.Location = New System.Drawing.Point(136, 105)
        Me.firstnumtxt.Name = "firstnumtxt"
        Me.firstnumtxt.Size = New System.Drawing.Size(191, 26)
        Me.firstnumtxt.TabIndex = 4
        '
        'secondnumtxt
        '
        Me.secondnumtxt.Location = New System.Drawing.Point(136, 156)
        Me.secondnumtxt.Name = "secondnumtxt"
        Me.secondnumtxt.Size = New System.Drawing.Size(191, 26)
        Me.secondnumtxt.TabIndex = 5
        '
        'answertxt
        '
        Me.answertxt.Location = New System.Drawing.Point(136, 335)
        Me.answertxt.Name = "answertxt"
        Me.answertxt.Size = New System.Drawing.Size(191, 26)
        Me.answertxt.TabIndex = 6
        '
        'sumbtn
        '
        Me.sumbtn.Location = New System.Drawing.Point(136, 211)
        Me.sumbtn.Name = "sumbtn"
        Me.sumbtn.Size = New System.Drawing.Size(318, 88)
        Me.sumbtn.TabIndex = 7
        Me.sumbtn.Text = "SUM"
        Me.sumbtn.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1200, 692)
        Me.Controls.Add(Me.sumbtn)
        Me.Controls.Add(Me.answertxt)
        Me.Controls.Add(Me.secondnumtxt)
        Me.Controls.Add(Me.firstnumtxt)
        Me.Controls.Add(Me.answer)
        Me.Controls.Add(Me.secondnumlbl)
        Me.Controls.Add(Me.firstnumlbl)
        Me.Controls.Add(Me.Button1)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
	Friend WithEvents firstnumlbl As Label
	Friend WithEvents secondnumlbl As Label
	Friend WithEvents answer As Label
	Friend WithEvents firstnumtxt As TextBox
	Friend WithEvents secondnumtxt As TextBox
	Friend WithEvents answertxt As TextBox
	Friend WithEvents sumbtn As Button
End Class
