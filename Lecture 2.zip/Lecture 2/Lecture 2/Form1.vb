﻿Public Class Form1


	Private Sub sumbtn_Click(sender As Object, e As EventArgs) Handles sumbtn.Click
		Dim num1, num2, sum As Integer

		num1 = firstnumtxt.Text
		num2 = secondnumtxt.Text
		sum = num1 + num2
		answertxt.Text = sum
	End Sub



	Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
		Dim fname, sname, total As Integer
		fname = CInt(InputBox("please enter your first number"))
		sname = CInt(InputBox("please enter your second number"))
		total = fname + sname
		MessageBox.Show("the answer is  " & total)
	End Sub
End Class
