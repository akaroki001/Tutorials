﻿Public Class Form1
    Private Sub Studgrdsysbtn_Click(sender As Object, e As EventArgs) Handles Studgrdsysbtn.Click
        Dim cat, final, total As Double

        cat = InputBox("please enter the CAT marks")
        final = InputBox("please enter the final exam marks")
        total = cat + final

        If total >= 70 Then
            MessageBox.Show("TOTAL MARKS:" & total & " " & "Grade is A")

        ElseIf total >= 60 Then
            MessageBox.Show("TOTAL MARKS:" & total & " " & "Grade is B")

        ElseIf total >= 50 Then
            MessageBox.Show("TOTAL MARKS:" & total & " " & "Grade is C")

        ElseIf total >= 40 Then
            MessageBox.Show("TOTAL MARKS:" & total & " " & "Grade is D")

        Else
            MessageBox.Show("FAILED")

        End If
    End Sub
End Class
