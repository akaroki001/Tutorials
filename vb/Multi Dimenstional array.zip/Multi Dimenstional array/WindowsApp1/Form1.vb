﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim bbit2023(2, 10) As Integer
        Dim cat, final, average2 As Double

        For x As Integer = 0 To 2

            For y As Integer = 0 To 10

                cat = InputBox("please enter the cat marks for student in " & "row" & x & "column" & y)
                final = InputBox("please enter the final exam marks for student " & "row" & x & "column" & y)
                bbit2023(x, y) = cat + final

            Next

        Next
        For x As Integer = 0 To 2
            For y As Integer = 0 To 10

                ListBox1.Items.Add("student number " & x & y & "=" & bbit2023(x, y))

            Next
        Next

        average2 = Faverage(bbit2023)

        MessageBox.Show("the average is " & average2)
    End Sub


    Function Faverage(ByVal bbit2016a(,) As Integer) As Double
        Dim average As Double
        Dim sum As Integer

        For x As Integer = 0 To 2
            For y As Integer = 0 To 10

                sum += bbit2016a(x, y)
            Next
        Next
        average = sum / bbit2016a.Length
        Return average
    End Function


End Class


