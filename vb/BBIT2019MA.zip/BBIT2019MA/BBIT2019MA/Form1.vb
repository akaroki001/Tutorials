﻿Public Class Form1

    '2 rows (subjects) and 3 columns (students)
    Dim grade(1, 2) As Double

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim subjects() As String = {"ACCOUNTING", "HUMAN RESOURCE"}

        'Clear previous outputs
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        TextBox1.Clear()
        TextBox2.Clear()

        'Input marks
        For i As Integer = 0 To 1
            MessageBox.Show("Please enter marks for " & subjects(i))

            For j As Integer = 0 To 2
                Dim input As String = InputBox("Enter marks for Student " & (j + 1))
                Dim mark As Double

                'Validate input
                If Double.TryParse(input, mark) Then
                    grade(i, j) = mark
                Else
                    MessageBox.Show("Invalid input. Please enter a numeric value.")
                    j -= 1 'repeat same student
                End If
            Next
        Next

        'Process data
        DisplayGrades()
        DisplayAverage()
        DisplayMaximum()

    End Sub

    'Display all grades
    Sub DisplayGrades()
        Dim subjects() As String = {"ACCOUNTING", "HUMAN RESOURCE"}

        For i As Integer = 0 To 1
            ListBox1.Items.Add("==== " & subjects(i) & " MARKS ====")

            For j As Integer = 0 To 2
                ListBox1.Items.Add("Student " & (j + 1) & ": " & grade(i, j))
            Next
        Next
    End Sub

    'Calculate and display average
    Sub DisplayAverage()
        Dim sum As Double = 0
        Dim count As Integer = 0

        For i As Integer = 0 To 1
            For j As Integer = 0 To 2
                sum += grade(i, j)
                count += 1
            Next
        Next

        Dim average As Double = sum / count
        TextBox1.Text = average.ToString("0.00")
    End Sub

    'Find and display maximum grade
    Sub DisplayMaximum()
        Dim max As Double = grade(0, 0)

        For i As Integer = 0 To 1
            For j As Integer = 0 To 2
                If grade(i, j) > max Then
                    max = grade(i, j)
                End If
            Next
        Next

        TextBox2.Text = max.ToString()
    End Sub

End Class