﻿Public Class Form1
    Dim total As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles gradingsys.Click
        Dim tcat, tfinal As Integer

        For counter As Integer = 1 To 10 Step 5
            tcat = InputBox("Enter the total cat marks")
            tfinal = InputBox("enter the tfinal marks")

            Calculate(tcat, tfinal)
            grade(total)
            pass(total)
            Moderation(total)


        Next



    End Sub

    Private Sub Calculate(ByVal cat_total As Integer, ByVal final_total As Integer)

        total = cat_total + final_total

        MessageBox.Show("the total mark is" & total)

    End Sub

    Private Sub grade(ByVal tfinal As Integer)
        If tfinal >= 70 Then
            MessageBox.Show("A")
        ElseIf tfinal >= 60 Then
            MessageBox.Show("B")
        ElseIf tfinal >= 50 Then
            MessageBox.Show("C")
        ElseIf tfinal >= 40 Then
            MessageBox.Show("D")
        Else
            MessageBox.Show("you got less than 40 ")

        End If
    End Sub


    Private Sub pass(ByVal tfinal As Integer)
        If tfinal > 40 Then
            MessageBox.Show("You have passed")
        Else
            MessageBox.Show("you have failed")

        End If

    End Sub

    Private Sub Moderation(ByRef mvalue As Integer)
        If mvalue = 38 Then
            mvalue += 2
            MessageBox.Show("Value moderated to " & mvalue)

        ElseIf mvalue = 39 Then
            mvalue += 1
            MessageBox.Show("Value moderated to " & mvalue)

        Else
            MessageBox.Show("No need for moderation ")
        End If

    End Sub

End Class
