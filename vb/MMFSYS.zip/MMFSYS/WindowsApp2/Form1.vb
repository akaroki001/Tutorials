﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim deposit, interest, months As Double

        For counter As Integer = 1 To 30

            deposit = CInt(InputBox("Enter the amount of our deposit: "))

            MessageBox.Show("monthly deposits offered are 1,3,6,12 or 24 months only")

            If deposit >= 5000 Then

                months = InputBox("Enter the number of months: ")

                If months = 1 Then
                    interest = deposit * 0.05

                ElseIf months = 3 Then
                    interest = deposit * 0.07

                ElseIf months = 6 Then
                    interest = deposit * 0.1

                ElseIf months = 12 Then
                    interest = deposit * 0.2

                ElseIf months = 24 Then
                    interest = deposit * 0.3

                Else
                    MessageBox.Show("The minimum months are 1,3,6,12 or 24 months only")
                End If


            Else

                MessageBox.Show("CANNOT INVEST!!! The minimun deposit is ksh 5000")

            End If

            MessageBox.Show("The interest earned is : " & interest)
        Next


    End Sub
End Class
