﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim roadMileage(,) As Integer = {{100, 162, 243, 124}, {162, 116, 147, 134}, {572, 244, 162, 183}}
        Displayarray(roadMileage)
        averagemileage(roadMileage)
        maximummileage(roadMileage)
    End Sub


    Private Sub Displayarray(ByVal RM(,) As Integer)
        For i As Integer = 0 To 2
            ListBox1.Items.Add("========================== ")
            ListBox1.Items.Add(" MP " & i)
            For j As Integer = 0 To 3
                ListBox1.Items.Add(RM(i, j))
            Next
        Next
    End Sub

    Private Sub averagemileage(ByVal RM(,) As Integer)

        Dim total As Integer = 0
        Dim average As Double = 0.0


        For i As Integer = 0 To 2
            For j As Integer = 0 To 3
                total += RM(i, j)
            Next
        Next
        average = total / RM.Length
        ListBox1.Items.Add("==========================")
        ListBox1.Items.Add("the average mileage is: " & average)
    End Sub

    Private Sub maximummileage(ByVal rm(,) As Integer)
        Dim maximumM As Integer
        maximumM = rm(0, 0)
        For i As Integer = 0 To 2
            For j As Integer = 0 To 3

                If rm(i, j) > maximumM Then
                    maximumM = rm(i, j)
                End If

            Next
        Next
        ListBox1.Items.Add("==========================")
        ListBox1.Items.Add("the maximum mileage is: " & maximumM)
    End Sub


End Class
