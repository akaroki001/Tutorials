﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim bbit2016(10) As Integer
        Dim cat, final, average2 As Double

        For counter As Integer = 0 To 9

            cat = InputBox("please enter the cat marks for student " & counter)
            final = InputBox("please enter the final exam marks for student " & counter)
            bbit2016(counter) = cat + final

        Next

        For counter As Integer = 0 To 9

            ListBox1.Items.Add("student number " & counter & "=" & bbit2016(counter))

        Next

        average2 = Faverage(bbit2016)

        MessageBox.Show("the average is " & average2)

    End Sub





    Function Faverage(ByVal bbit2016a() As Integer) As Double
        Dim average As Double
        Dim sum As Integer
        For counter1 As Integer = 0 To 9

            sum += bbit2016a(counter1)
        Next
        average = sum / 10
        Return average
    End Function


End Class
