﻿Public Class Form1

    Private Sub gradingsys_Click(sender As Object, e As EventArgs) Handles gradingsys.Click

        Dim tcat, tfinal, total As Integer


        For counter As Integer = 1 To 10

            Dim catInput As String = InputBox("Enter the total cat marks (0 - 30)")

            If Not Integer.TryParse(catInput, tcat) Then
                MessageBox.Show("Invalid input. Please enter a whole number for CAT marks.")
                counter -= 1   ' don't count this iteration — retry the same student
                Continue For
            End If

            Dim finalInput As String = InputBox("enter the tfinal marks (0 - 70)")

            If Not Integer.TryParse(finalInput, tfinal) Then
                MessageBox.Show("Invalid input. Please enter a whole number for Final marks.")
                counter -= 1   ' don't count this iteration — retry the same student
                Continue For
            End If

            If tcat <= 30 And tfinal <= 70 Then

                total = Calculate(tcat, tfinal)
                total = Moderation(total)
                grade(total)
                pass_status(total)
            Else

                MessageBox.Show("The CAT or Final exam marks have exceeded the required mark")

            End If

        Next

    End Sub



    Private Function Calculate(ByVal cat_total As Integer, ByVal final_total As Integer) As Integer

        Return cat_total + final_total

    End Function

    Private Function Moderation(ByRef score_value As Integer) As Integer
        If score_value = 38 Or score_value = 39 Then

            score_value = 40

            MessageBox.Show("Your score has been moderated to 40")

        End If

        Return score_value

    End Function

    Private Sub grade(ByVal tfinal As Integer)

        If tfinal >= 70 Then
            MessageBox.Show("A")
        ElseIf tfinal >= 60 Then
            MessageBox.Show("B")
        ElseIf tfinal >= 50 Then
            MessageBox.Show("C")
        ElseIf tfinal >= 40 Then
            MessageBox.Show("D")
        Else
            MessageBox.Show("F ")

        End If

    End Sub


    Private Sub pass_status(ByVal tfinal As Integer)

        If tfinal >= 40 Then
            MessageBox.Show("You have passed")
        Else
            MessageBox.Show("you have failed")

        End If

    End Sub


End Class
