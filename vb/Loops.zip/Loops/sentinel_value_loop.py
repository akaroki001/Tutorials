#program for registering students to a new club
print("welcome to the artificial intelligence club")

age = int(input("please enter your age"))
while age != 0:
    name = input("please enter your name")
    gender = input("please enter your gender")
    program = input("please enter your program")

    print("\n--- Next member ---")

    # Update read (ask again at the end of the loop)
    age = int(input("please enter your age"))
print("You are now exiting the iRegistrationSystem")