﻿Public Class Form1
    Private Sub gradingbtn_Click(sender As Object, e As EventArgs) Handles gradingbtn.Click

        Dim tcat, finalexam, totalexam, counter As Integer
        Dim username As String = "admin"
        Dim password As String = "password"
        Dim remark As String

        username = InputBox("please enter your username")
        password = InputBox("please enter your password")

        If username = "admin" And password = "password" Then

            MessageBox.Show("welcome to the TUK Grading system")
            For counter = 0 To 2
                tcat = CInt(InputBox("please enter the total cat marks"))
                finalexam = CInt(InputBox("please enter the final exam marks"))
                totalexam = tcat + finalexam

                MessageBox.Show("Total marks = " & totalexam)
                Resultslbx.Items.Add("Total marks = " & totalexam)
                Resultslbx.Items.Add("+++++++++++++++++++++++++++")
                If totalexam >= 70 Then
                    remark = "passed"
                    MessageBox.Show("Grade is A" & remark)
                    Resultslbx.Items.Add("Grade is A" & remark)

                ElseIf totalexam >= 60 Then
                    MessageBox.Show("Grade is B")
                    remark = "passed"
                    Resultslbx.Items.Add("Grade is B" & remark)

                ElseIf totalexam >= 50 Then
                    remark = "passed"
                    MessageBox.Show("Grade is C")
                    Resultslbx.Items.Add("Grade is C" & remark)

                ElseIf totalexam >= 40 Then
                    remark = "passed"
                    MessageBox.Show("Grade is D")
                    Resultslbx.Items.Add("Grade is D" & remark)
                Else
                    MessageBox.Show("Failed")

                End If


            Next
        Else
            MessageBox.Show("Wrong password attempt again")

        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
