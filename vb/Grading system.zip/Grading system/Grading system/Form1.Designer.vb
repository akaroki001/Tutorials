﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gradingbtn = New System.Windows.Forms.Button()
        Me.Resultslbx = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'gradingbtn
        '
        Me.gradingbtn.Location = New System.Drawing.Point(46, 37)
        Me.gradingbtn.Name = "gradingbtn"
        Me.gradingbtn.Size = New System.Drawing.Size(262, 166)
        Me.gradingbtn.TabIndex = 0
        Me.gradingbtn.Text = "Welcome to TUK Grading System"
        Me.gradingbtn.UseVisualStyleBackColor = True
        '
        'Resultslbx
        '
        Me.Resultslbx.FormattingEnabled = True
        Me.Resultslbx.Location = New System.Drawing.Point(349, 37)
        Me.Resultslbx.Name = "Resultslbx"
        Me.Resultslbx.Size = New System.Drawing.Size(259, 368)
        Me.Resultslbx.TabIndex = 1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Resultslbx)
        Me.Controls.Add(Me.gradingbtn)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gradingbtn As Button
    Friend WithEvents Resultslbx As ListBox
End Class
