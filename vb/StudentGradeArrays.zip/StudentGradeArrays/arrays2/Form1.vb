﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim bbit2024(9) As Integer
        Dim cat, final, average2 As Double

        For counter As Integer = 0 To 9

            cat = InputBox("please enter the cat marks for student " & (counter + 1))
            final = InputBox("please enter the final exam marks for student " & (counter + 1))
            bbit2024(counter) = cat + final

        Next

        For counter As Integer = 0 To 9

            ListBox1.Items.Add("student number " & counter & "=" & bbit2024(counter))

        Next

        average2 = Faverage(bbit2024)

        MessageBox.Show("the average is " & average2)

        GetGrades(bbit2024)

    End Sub





    Function Faverage(ByVal bbit2024a() As Integer) As Double
        Dim average As Double
        Dim sum As Integer

        For counter1 As Integer = 0 To 9

            sum += bbit2024a(counter1)

        Next

        average = sum / bbit2024a.Length

        Return average

    End Function

    Sub GetGrades(ByVal scores() As Integer)

        ListBox1.Items.Add("---- Grades ----")

        For i As Integer = 0 To scores.Length - 1

            Dim grade As String

            If scores(i) >= 70 Then
                grade = "A"
            ElseIf scores(i) >= 60 Then
                grade = "B"
            ElseIf scores(i) >= 50 Then
                grade = "C"
            ElseIf scores(i) >= 40 Then
                grade = "D"
            Else
                grade = "Fail"
            End If

            ListBox1.Items.Add("Student " & (i + 1) & " Grade = " & grade)
        Next
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub
End Class
