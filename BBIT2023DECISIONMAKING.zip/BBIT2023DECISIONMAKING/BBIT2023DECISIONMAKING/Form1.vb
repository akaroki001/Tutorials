﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim fnum, snum, total As Double

        fnum = fnumtxt.Text
        snum = snumtxt.Text

        If fnum > snum Then
            total = fnum + snum
            answertxt.Text = total
        Else
            total = fnum * snum
            answertxt.Text = total
        End If
    End Sub
End Class
