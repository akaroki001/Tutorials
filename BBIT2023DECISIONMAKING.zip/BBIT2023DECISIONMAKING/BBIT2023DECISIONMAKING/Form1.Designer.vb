﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.fnamelbl = New System.Windows.Forms.Label()
        Me.snamelbl = New System.Windows.Forms.Label()
        Me.Answerlbl = New System.Windows.Forms.Label()
        Me.fnumtxt = New System.Windows.Forms.TextBox()
        Me.snumtxt = New System.Windows.Forms.TextBox()
        Me.answertxt = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft YaHei", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(423, 266)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(272, 76)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Calculate"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'fnamelbl
        '
        Me.fnamelbl.AutoSize = True
        Me.fnamelbl.Font = New System.Drawing.Font("Microsoft YaHei", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fnamelbl.Location = New System.Drawing.Point(96, 119)
        Me.fnamelbl.Name = "fnamelbl"
        Me.fnamelbl.Size = New System.Drawing.Size(321, 42)
        Me.fnamelbl.TabIndex = 1
        Me.fnamelbl.Text = "Enter first Number"
        '
        'snamelbl
        '
        Me.snamelbl.AutoSize = True
        Me.snamelbl.Font = New System.Drawing.Font("Microsoft YaHei", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.snamelbl.Location = New System.Drawing.Point(43, 199)
        Me.snamelbl.Name = "snamelbl"
        Me.snamelbl.Size = New System.Drawing.Size(374, 42)
        Me.snamelbl.TabIndex = 2
        Me.snamelbl.Text = "Enter Second Number"
        '
        'Answerlbl
        '
        Me.Answerlbl.AutoSize = True
        Me.Answerlbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Answerlbl.Location = New System.Drawing.Point(246, 360)
        Me.Answerlbl.Name = "Answerlbl"
        Me.Answerlbl.Size = New System.Drawing.Size(130, 37)
        Me.Answerlbl.TabIndex = 3
        Me.Answerlbl.Text = "Answer"
        '
        'fnumtxt
        '
        Me.fnumtxt.Location = New System.Drawing.Point(423, 134)
        Me.fnumtxt.Name = "fnumtxt"
        Me.fnumtxt.Size = New System.Drawing.Size(272, 26)
        Me.fnumtxt.TabIndex = 4
        '
        'snumtxt
        '
        Me.snumtxt.Location = New System.Drawing.Point(423, 214)
        Me.snumtxt.Name = "snumtxt"
        Me.snumtxt.Size = New System.Drawing.Size(272, 26)
        Me.snumtxt.TabIndex = 5
        '
        'answertxt
        '
        Me.answertxt.Location = New System.Drawing.Point(423, 360)
        Me.answertxt.Name = "answertxt"
        Me.answertxt.Size = New System.Drawing.Size(272, 26)
        Me.answertxt.TabIndex = 6
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(1170, 620)
        Me.Controls.Add(Me.answertxt)
        Me.Controls.Add(Me.snumtxt)
        Me.Controls.Add(Me.fnumtxt)
        Me.Controls.Add(Me.Answerlbl)
        Me.Controls.Add(Me.snamelbl)
        Me.Controls.Add(Me.fnamelbl)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents fnamelbl As Label
    Friend WithEvents snamelbl As Label
    Friend WithEvents Answerlbl As Label
    Friend WithEvents fnumtxt As TextBox
    Friend WithEvents snumtxt As TextBox
    Friend WithEvents answertxt As TextBox
End Class
