﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.gradingsys = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'gradingsys
        '
        Me.gradingsys.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.gradingsys.Font = New System.Drawing.Font("Sigmar One", 20.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gradingsys.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.gradingsys.Location = New System.Drawing.Point(317, 176)
        Me.gradingsys.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gradingsys.Name = "gradingsys"
        Me.gradingsys.Size = New System.Drawing.Size(579, 256)
        Me.gradingsys.TabIndex = 0
        Me.gradingsys.Text = "STUDENT GRADING SYSTEM"
        Me.gradingsys.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(1200, 692)
        Me.Controls.Add(Me.gradingsys)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gradingsys As Button
End Class
