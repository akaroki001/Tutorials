﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Declare Variables
        Dim password As String = "1234" 'password for access'
        Dim employeeNumber As String
        Dim employeeName As String
        Dim grossSalary As Double
        Dim incomeTax As Double
        Dim housingLevy As Double
        Dim medicalLevy As Double
        Dim netSalary As Double

        'prompt the user for a password

        password = InputBox("Enter Password to Access Payroll Calculation")

        ' Check if the password is correct

        If password = "1234" Then

            For counter As Integer = 1 To 3
                employeeNumber = InputBox("Enter Employee Number")
                employeeName = InputBox("Enter Employee Name")
                grossSalary = InputBox("Enter Gross Salary")

                If grossSalary >= 100000 Then
                    incomeTax = grossSalary * 0.3
                    medicalLevy = grossSalary * 0.015
                    housingLevy = grossSalary * 0.015
                    netSalary = grossSalary - (medicalLevy + housingLevy + incomeTax)

                ElseIf grossSalary > 50000 And grossSalary < 100000 Then
                    incomeTax = grossSalary * 0.25
                    medicalLevy = grossSalary * 0.015
                    housingLevy = grossSalary * 0.015
                    netSalary = grossSalary - (medicalLevy + housingLevy + incomeTax)

                ElseIf grossSalary >= 10000 And grossSalary < 50000 Then
                    incomeTax = grossSalary * 0.15
                    medicalLevy = grossSalary * 0.015
                    housingLevy = grossSalary * 0.015
                    netSalary = grossSalary - (medicalLevy + housingLevy + incomeTax)

                Else
                    incomeTax = 0
                    medicalLevy = 0
                    housingLevy = 0
                    netSalary = grossSalary - (medicalLevy + housingLevy + incomeTax)
                End If

                'display the results
                MessageBox.Show(" Income Tax: " & incomeTax & "MedicalLevy: " & medicalLevy & "Housing_Levy: " & housingLevy)
                MessageBox.Show("Net Salary" & netSalary)
            Next

        Else
            MessageBox.Show("Incorrect Password. Access Denied.")
        End If
    End Sub
End Class
