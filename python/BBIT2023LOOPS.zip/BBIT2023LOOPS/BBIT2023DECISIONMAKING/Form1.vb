﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim fnum, snum, total As Double

        For counter As Integer = 0 To 2

            fnum = InputBox("please enter the first number")

            snum = InputBox("please enter the second number")

            If fnum > snum Then
                total = fnum + snum
                MessageBox.Show("The total is " & total)
            Else
                total = fnum * snum
                MessageBox.Show("the total is " & total)
            End If
            MessageBox.Show("loop " & counter)
        Next

        MessageBox.Show("end of loop")

    End Sub




End Class
