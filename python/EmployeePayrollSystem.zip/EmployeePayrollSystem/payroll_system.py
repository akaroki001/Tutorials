# Simple Payroll System with Tax Deduction 

class Employee:
    TAX_RATE = 0.05   # 5% tax

    def __init__(self, emp_id, name):
        self.emp_id = emp_id
        self.name = name

    def pay(self):   # overridden in subclasses
        return 0

    def net_pay(self):
        gross = self.pay()
        tax = gross * Employee.TAX_RATE
        return gross - tax


class Management(Employee):
    def __init__(self, emp_id, name, basic, house, transport):
        super().__init__(emp_id, name)
        self.basic = basic
        self.house = house
        self.transport = transport

    def pay(self):
        bonus = 0.10 * self.basic
        return self.basic + self.house + self.transport + bonus


class MiddleManagement(Employee):
    def __init__(self, emp_id, name, basic, resp):
        super().__init__(emp_id, name)
        self.basic = basic
        self.resp = resp

    def pay(self):
        return self.basic + self.resp + 5000   # fixed perk


class ContractSales(Employee):
    def __init__(self, emp_id, name, base, sales, rate):
        super().__init__(emp_id, name)
        self.base = base
        self.sales = sales
        self.rate = rate

    def pay(self):
        commission = self.sales * self.rate
        return self.base + commission + 2000  # small allowance


def add_employee(employees):
    print("\n1. Management  2. Middle Mgmt  3. Contract Sales")
    level = input("Level: ")
    emp_id = input("ID: ")
    name = input("Name: ")

    if level == "1":
        basic = float(input("Basic salary: "))
        house = float(input("House allowance: "))
        transport = float(input("Transport allowance: "))
        employees.append(Management(emp_id, name, basic, house, transport))

    elif level == "2":
        basic = float(input("Basic salary: "))
        resp = float(input("Responsibility allowance: "))
        employees.append(MiddleManagement(emp_id, name, basic, resp))

    elif level == "3":
        base = float(input("Base pay: "))
        sales = float(input("Total sales: "))
        rate = float(input("Commission rate (e.g. 0.05): "))
        employees.append(ContractSales(emp_id, name, base, sales, rate))


def show_payroll(employees):
    print("\n--- PAYROLL REPORT ---")
    total = 0

    for e in employees:    # loop + polymorphism
        gross = e.pay()
        net = e.net_pay()
        total += net
        print(f"{e.emp_id} {e.name} | Gross: {gross:,.2f} | Net: {net:,.2f}")

    print(f"TOTAL NET PAYROLL COST: {total:,.2f}")


def main():
    employees = []

    while True:
        print("\n1.Add Employee  2.Show Payroll  3.Exit")
        choice = input("Choice: ")

        if choice == "1":
            add_employee(employees)
        elif choice == "2":
            show_payroll(employees)
        elif choice == "3":
            print("Goodbye.")
            break


main()
