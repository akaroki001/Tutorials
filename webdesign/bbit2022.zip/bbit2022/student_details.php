<?php
declare(strict_types=1);
require_once __DIR__ . "/config/student_config.php"; // loads $pdo

// Only process when the form was submitted via POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo "<p>This page expects form submission via POST.</p>";
    exit;
}

// Helper: safely fetch and escape POST values for DISPLAY (not for DB)
function post_value(string $key): string {
    $value = $_POST[$key] ?? '';
    return trim((string)$value);
}

$studNum  = post_value("StudNum");
$studName = post_value("StudName");
$dept     = post_value("dept");
$emailRaw = post_value("email");

// Basic validation
$errors = [];

if ($studNum === '')  $errors[] = "Student number is required.";
if ($studName === '') $errors[] = "Student name is required.";
if ($dept === '')     $errors[] = "Department is required.";

if ($emailRaw === '') {
    $errors[] = "Email is required.";
} elseif (!filter_var($emailRaw, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Please enter a valid email address.";
}

// If validation fails, show errors and stop
if (!empty($errors)) {
    echo "<h3>Form Errors</h3><ul>";
    foreach ($errors as $e) {
        echo "<li>" . htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . "</li>";
    }
    echo "</ul>";
    echo "<p><a href=\"javascript:history.back()\">Go back</a></p>";
    exit;
}

// Insert into database (prepared statement)
try {
    $sql = "INSERT INTO student_submissions (stud_num, stud_name, dept, email)
            VALUES (:stud_num, :stud_name, :dept, :email)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ":stud_num"  => $studNum,
        ":stud_name" => $studName,
        ":dept"      => $dept,
        ":email"     => $emailRaw,
    ]);
} catch (PDOException $e) {
    // Handle duplicates cleanly (because of UNIQUE constraints)
    // MySQL duplicate entry error code is commonly 1062
    if ((int)($e->errorInfo[1] ?? 0) === 1062) {
        echo "<h3>Submission Error</h3>";
        echo "<p>This student number or email already exists.</p>";
        echo "<p><a href=\"javascript:history.back()\">Go back</a></p>";
        exit;
    }

    http_response_code(500);
    echo "<h3>Server Error</h3>";
    echo "<p>Could not save your submission. Please try again later.</p>";
    exit;
}

// Escape for safe HTML display
$studNumEsc  = htmlspecialchars($studNum, ENT_QUOTES, 'UTF-8');
$studNameEsc = htmlspecialchars($studName, ENT_QUOTES, 'UTF-8');
$deptEsc     = htmlspecialchars($dept, ENT_QUOTES, 'UTF-8');
$emailEsc    = htmlspecialchars($emailRaw, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="css/contact_us.css">
  <title>Student Details</title>
</head>
<body>
    
<h2>Submission Received</h2>
<p>Welcome <strong><?php echo $studNumEsc . " " . $studNameEsc; ?></strong></p>
<p>Your department is: <strong><?php echo $deptEsc; ?></strong></p>
<p>Your email address is: <strong><?php echo $emailEsc; ?></strong></p>

</body>
</html>
