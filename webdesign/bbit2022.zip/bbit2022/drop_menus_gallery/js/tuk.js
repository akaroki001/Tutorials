
    function calcSum() {
    let value1 = parseInt(document.mainForm.textBox1.value);
    let value2 = parseInt(document.mainForm.textBox2.value);

    let sum = value1 + value2;

    document.mainForm.textBoxSum.value = sum;
}

