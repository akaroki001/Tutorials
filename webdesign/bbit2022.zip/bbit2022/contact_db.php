<html>
    
<head>
    
    <title> Contact without validation </title>
    <link rel="stylesheet" href="main.css">
    
</head>
    
<body>
    
    <div class="form">

        <form action="student_details.php" method="POST">
            
            Student_Number: <input type="text" name="StudNum"><br>
            Student_Name: <input type="text" name="StudName"><br>
            Department: <input type="text" name="dept"><br>
            E-mail: <input type="text" name="email"><br>

            <input type="submit">
            
        </form>
        
    </div>
</body>
    
</html>