<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Technical university of kenya </title>
    <link rel="stylesheet" href="css/main.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</head>
    
<body>
    <!-- Main Div Container -->
   <div class="main_container">
       <!--  Div Container for the top menu -->
       <div class="top_menu"> 
           <ul>
                <li><a href="http://library.tukenya.ac.ke/">Library</a></li>
                <li><a href="https://sgas.tukenya.ac.ke/">Graduate School</a></li>
                <li><a href="#">I_repository</a></li>
                <li><a href="#">Staff Email</a></li>
                <li><a href="3">Student Portal</a></li>
                <li><a href="#">E-learning Portal</a></li>
                <li><a href="#">Tenders</a></li>
           </ul>
       
       </div>
       
       <!-- header -->
       <header> 
           <div class="header">
               
           <img src="logo.png"/>
               
           </div>
               
           <div class= "email">
                   
               <h6>EMAIL</h6>
               <p> info@tukenya.ac.ke /</p>
               <p>  vc@tukenya.ac.ke /  </p>
               <p>admissions@students.tukenya </p>
                   
           </div>
           
           <div class= "phone_number">  
               <h6>PHONE NUMBER</h6>
               <p>+254 0203343672 /  </p>
               <p>0202982182 /</p>
               <P>0746673317 / 0108555666</P>
           </div>
               
           <div class= "location">  
                 <h6>ADDRESS</h6>
               <p> P.O. Box 52428 - 00200,</p>
               <p> Haile Selassie Avenue,</p>
               <p> Nairobi, Kenya </p> 
           </div>
               
           
           <div class="social_media">
               <img src="images/fb.jpeg"/>
               <img src="images/x.png"/>
               <img src="images/linkedin.png"/>
               <img src="images/youtube.png"/>
           </div>
           
       </header>
       
       <!-- navigation  -->
       <nav> 
       <ul class="menu">
           <li><a href="#">Home</a></li>
           
           <li class="dropdown"><a href="#">About us</a>
               
               <div class="dropdown-content">
               
                <ul>
                   <li class="menu_headings">The institution</li>
                   <li> <a href="#">TUK-Profile</a> </li>
                   <li> <a href="#">TUK-Photos</a></li>
                   <li> <a href="#">TUK-News</a></li> 
               </ul>
               
               <ul>
                   <li class="menu_headings">Governance and Management </li>
                   <li> <a href="#">The chancellor</a> </li>
                   <li> <a href="#">The council </a></li>
                   <li> <a href="#">The vice chancellor</a></li> 
               </ul>
               
               <ul> 
                   <li class="menu_headings">Administration </li>
                   <li> <a href="#">Academic and Student affaris</a> </li>
                   <li> <a href="#">Research and Development </a></li>
                   <li> <a href="#">InstitutionAL Development and Enterprise</a></li> 
               </ul>
               </div>
           </li> 
           <li class="dropdown"><a href="#">Faculties and Departments</a>
               
               <div class="dropdown-content">
                   
               <ul> 
                   <li class="menu_headings">Faculty of Engineering and the Built Environment (FEBE)</li>
                   <li> <a href="#">Department of Architecture, Design and Planning (DADP)</a> </li>
                   <li> <a href="#">Department of Chemical and Biosystems Engineering (DCBE)</a></li>
                   <li> <a href="#">Department of Civil and Resource Engineering (DCRE)</a></li> 
               </ul>
               
               <ul> 
                   <li class="menu_headings">Faculty of Social Sciences and Technology (FSST) </li>
                   <li> <a href="#">Department of Business and Management Studies (DBMS)</a> </li>
                   <li> <a href="#">Department of Creative Arts and Media (DCAM) </a></li>
                   <li> <a href="#">Department of Hospitality and Human Ecology (DHHE)</a></li> 
               </ul>
               
               <ul>
                   <li class="menu_headings">Faculty of Applied Sciences and Technology (FAST)</li>
                   <li> <a href="#">Department of Biological and Life Sciences (DBLS)</a> </li>
                   <li> <a href="#">Department of Computing and Information Technologies (DCIT) </a></li>
                   <li> <a href="#">Department of Chemistry and Materials Science (DCMS)</a></li> 
               </ul>
               </div>
           </li> 
           <li><a href="#"> TUK-Academics </a></li>
           <li><a href="javascript_html.html"> Javascript </a></li>
           <li><a href="#"> Students Support </a></li>
           <li><a href="gallery.html"> Gallery </a></li>
           <li><a href="#"> Portals </a></li>
           <li><a href="contact_us.php"> Contact us </a></li>
       </ul>
    
       </nav>
       
       <!-- section for the slideshow -->
       <section>
      <div class="container mt-4">
    <!-- Carousel -->
    <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">

        <!-- Indicators -->
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2"></button>
        </div>

        <!-- Slides -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="images/slideshow/img1.jpg"  class="d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/slideshow/img2.jpg" class="d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/slideshow/img3.jpg" class="d-block w-100">
            </div>
            <div class="carousel-item">
                <img src="images/slideshow/img4.jpg" class="d-block w-100">
            </div>
        </div>

        <!-- Navigation controls -->
        <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>

        <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>

    </div>

</div>
       
       </section>
       
       <!-- article   -->
       
       <article>     
           <!-- section  -->
         <section class="news_section">  
             
           <p>NEWS</p>
             
           <img src="unnamed_7.jpg"/>
             
           <p>The German University of Applied Sciences and the Technical University of Kenya, have taken a giant stride in the use of digital technologies in preserving cultural heritage. The two institutions organised a three-day Digital Twin Project seminar at the National Museums of Kenya (NMK). The seminar was themed: “Sharing Digitisation Lessons Based on a Kenyan Case Study.”</p>
             
           <p>NEWS</p>
             
           <img src="unnamed_7.jpg"/>
             
           <p>The German University of Applied Sciences and the Technical University of Kenya, have taken a giant stride in the use of digital technologies in preserving cultural heritage. The two institutions organised a three-day Digital Twin Project seminar at the National Museums of Kenya (NMK). The seminar was themed: “Sharing Digitisation Lessons Based on a Kenyan Case Study.”</p>
            
           <p>NEWS</p>
             
           <img src="unnamed_7.jpg"/>
             
           <p>The German University of Applied Sciences and the Technical University of Kenya, have taken a giant stride in the use of digital technologies in preserving cultural heritage. The two institutions organised a three-day Digital Twin Project seminar at the National Museums of Kenya (NMK). The seminar was themed: “Sharing Digitisation Lessons Based on a Kenyan Case Study.”</p>
             
           </section>
           <!-- aside -->
           <aside> 
            <p>NOTICES </p> 
           <P> THE 14TH GRADUATION CEREMONY ANNOUNCEMENT : The Technical University of Kenya is pleased to announce its 14th Graduation Ceremony, scheduled for Tuesday 25th November, 2025, at 8:30 a.m. at the University’s Graduation Square</P>
           <P> THE 14TH GRADUATION CEREMONY ANNOUNCEMENT : The Technical University of Kenya is pleased to announce its 14th Graduation Ceremony, scheduled for Tuesday 25th November, 2025, at 8:30 a.m. at the University’s Graduation Square</P>
           <P> THE 14TH GRADUATION CEREMONY ANNOUNCEMENT : The Technical University of Kenya is pleased to announce its 14th Graduation Ceremony, scheduled for Tuesday 25th November, 2025, at 8:30 a.m. at the University’s Graduation Square</P>
           <P> THE 14TH GRADUATION CEREMONY ANNOUNCEMENT : The Technical University of Kenya is pleased to announce its 14th Graduation Ceremony, scheduled for Tuesday 25th November, 2025, at 8:30 a.m. at the University’s Graduation Square</P>
           <P> THE 14TH GRADUATION CEREMONY ANNOUNCEMENT : The Technical University of Kenya is pleased to announce its 14th Graduation Ceremony, scheduled for Tuesday 25th November, 2025, at 8:30 a.m. at the University’s Graduation Square</P>
           <P> THE 14TH GRADUATION CEREMONY ANNOUNCEMENT : The Technical University of Kenya is pleased to announce its 14th Graduation Ceremony, scheduled for Tuesday 25th November, 2025, at 8:30 a.m. at the University’s Graduation Square</P>
          
           </aside>
       
       </article>
       
       <!-- section  -->
       
      <section class="tuk_academic_departments">        
       
       <div class="info"> 
           <img src="applied.jpg"/> 
          
          <p>Faculty of engineering </p>
          
          </div>
          
        <div class="info"> 
            <img src="engineering.jpg"/> 
          <p> Faculty of social sciences </p>
          
          </div>
          
        <div class="info"> 
            <img src ="social.jpg"/> 
          <p> Faculty of applied sciences </p>
       </div>
       </section> 
       
       <!-- footer -->
       <footer> 
       <p> Address </p>
       <p> email us </p>
        <p> phone number  </p>
           
        <img src="tuk-iso.png"/>
        <p>copyright 2025</p>
           
       </footer>
       
       <script type="text/javascript">
     alert('Tomorrow is a public holiday it will be gazeted today');
  </script>	

         <script type="text/javascript">
     document.write('welcome bbit 2022 tomorrow is a public holiday');
  </script>	

       
    </div> 
    
 

    <!-- Your Custom JS -->
<script>
    // Initialize the carousel using JavaScript API
    const carousel = new bootstrap.Carousel('#myCarousel', {
       interval: 2000,     // auto-slide every 2 seconds
        pause: "hover"      // pause when mouse hovers
    });

    // Example actions:
    // carousel.next();     // go to next slide manually
    // carousel.prev();     // go to previous slide
    // carousel.pause();    // stop automatic sliding
</script>
</body>
    
</html>