<html>
<head><title></title></head>
<body>

Welcome <?php echo $_POST["StudNum"]. $_POST["StudName"] ; ?> <br> <br>
Your department is: <?php echo $_POST["dept"]; ?> <br> <br>
Your email address is: <?php echo $_POST["email"]; ?> 
    
<!-- not safe can be hacked for example pasting <script>alert('Hacked')</script> -->
    
<!-- use this code for security-->
    welcome
  <?php 
     echo htmlspecialchars($_POST["StudNum"] ?? ''); 
     echo htmlspecialchars($_POST["StudName"] ?? '');
     echo htmlspecialchars($_POST["email"] ?? '');
  ?>


    
</body>
</html>