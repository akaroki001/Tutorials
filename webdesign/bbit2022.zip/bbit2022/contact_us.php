<html>
    
<head> 

    <title> FORMS </title>

    <link rel="stylesheet" href="main.css">
    
</head>
    
<body>
    
    <div class="form">

    <a href="contact.php"> contact_without_validation </a> <br>
    <a href="contactval.php"> contact_with_validation </a> <br>
    <a href="contact_db.php"> contact_page that store information in a database </a> <br>
    </div>


</body>
    
</html>