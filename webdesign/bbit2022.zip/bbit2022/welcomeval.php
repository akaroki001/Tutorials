<html>
<body>

Welcome <?php echo $_POST["StudNum"]. $_POST["StudName"] ; ?><br>
        <?php echo $_POST["StudName"]; ?><br>
Your department is: <?php echo $_POST["dept"]; ?> <br>
Your email address is: <?php echo $_POST["email"]; ?>
</body>
</html>