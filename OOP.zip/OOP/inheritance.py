class Student:
    def __init__(self):
        self.name = input("please enter your student name")
        self.number = input("please enter the student number")
        self.course = input("please enter the program")

    def display_student(self):
        print(f'Name: {self.name} Student_Number: {self.number} Course: {self.course}')


class Masters_student(Student):
    def __init__(self):
        super().__init__()
        self.thesis = input("what type of thesis will you undertake")

    def display_student(self):
        print(f'Name: {self.name} Student_Number: {self.number} Course: {self.course} Thesis_type: {self.thesis}')


class Phd(Student):
    def __init__(self):
        super().__init__()
        self.publishing = int(input("please indicate the number of publications"))

    def publications(self):
        if self.publishing >= 3:
            print("You can graduate")
        else:
            print("you cannot graduate")

    def display_student(self):
        print(
            f'Name: {self.name} Student_Number: {self.number} Course: {self.course} Number_of_publications: {self.publishing}')


S1 = Student()
S1.display_student()
m1 = Masters_student()
m1.display_student()
p1 = Phd()
p1.display_student()
p1.publications()
