class Payment:
    def pay(self, amount):
        pass


class Mpesa(Payment):
    def pay(self, amount):
        amount = amount + 100
        return f"Paying {amount} via Mpesa"


class CreditCard(Payment):
    def pay(self, amount):
        amount = amount + 150
        return f"Paying {amount} using Credit Card"


class BankTransfer(Payment):
    def pay(self, amount):
        amount = amount + 200
        return f"Transferring {amount} via Bank"


# Polymorphic use:
payments = [
    Mpesa(),
    CreditCard(),
    BankTransfer()
]

for p in payments:
    print(p.pay(1000))
