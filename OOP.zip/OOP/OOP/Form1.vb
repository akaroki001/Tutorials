﻿

Public Class Form1

    ' Student class to handle grade calculation
    Public Class Student
        Private _midTerm As Double
        Private _finalExam As Double

        ' Properties with validation
        Public Property MidTerm As Double
            Get
                Return _midTerm
            End Get
            Set(value As Double)
                If value < 0 Or value > 30 Then
                    Throw New ArgumentException("Mid-term must be between 0-30")
                End If
                _midTerm = value
            End Set
        End Property

        Public Property FinalExam As Double
            Get
                Return _finalExam
            End Get
            Set(value As Double)
                If value < 0 Or value > 70 Then
                    Throw New ArgumentException("Final exam must be between 0-100")
                End If
                _finalExam = value
            End Set
        End Property

        ' Calculate total marks
        Public Function CalculateTotal() As Double
            Return _midTerm + _finalExam
        End Function

        ' Determine grade based on total marks
        Public Function DetermineGrade() As String
            Dim total = CalculateTotal()
            Select Case total
                Case Is >= 70 : Return "A"
                Case Is >= 60 : Return "B"
                Case Is >= 50 : Return "C"
                Case Is >= 40 : Return "D"
                Case Else : Return "F"
            End Select
        End Function
    End Class

    ' Array to store student records
    Private studentRecords(2) As Integer ' Array size 10
    Private recordCount As Integer = 0


    ' calculate average score from students records'
    Private Function calculateaverage(ByRef studentRecords() As Integer) As Double
        Dim total As Double = 0
        Dim count As Integer = 0
        Dim average As Double = 0
        For count = 0 To 2

            If studentRecords(count) > 0 Then ' only consider valid scores
                total += studentRecords(count)
            End If

        Next
        average = total / (count)
        Return average
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        For counter As Integer = 0 To 2


            Try


                ' Create new student object
                Dim student As New Student()

                ' Set properties with input validation
                student.MidTerm = InputBox("please enter your mid-term marks (0-30)")
                student.FinalExam = InputBox("please enter your mid-term marks (0-70)")

                ' Calculate results
                'Dim total = student.CalculateTotal()
                Dim grade = student.DetermineGrade()
                studentRecords(counter) = student.CalculateTotal()

                ' Display results
                ListBox1.Items.Add("total_exam marks: " & studentRecords(counter))
                ListBox1.Items.Add("finalgrade: " & grade)
                ListBox1.Items.Add("**********************")


            Catch ex As FormatException
                MessageBox.Show("Please enter valid numbers", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Catch ex As ArgumentException
                MessageBox.Show(ex.Message, "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)


            End Try
        Next
        ListBox1.Items.Add("the average score for the students is" & calculateaverage(studentRecords))
    End Sub
End Class


