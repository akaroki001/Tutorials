<?php
$conn = new mysqli("localhost", "root", "", "student_db");

if ($conn->connect_error) {
    die("Connection failed");
}

$result = $conn->query("SELECT * FROM students");
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Students</title>
</head>
<body>

<h2>Registered Students</h2>

<table border cellpadding="5">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Age</th>
        <th>Course</th>
        <th>Year</th>
        <th>Email</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()) { ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['age']; ?></td>
        <td><?php echo $row['course']; ?></td>
        <td><?php echo $row['year_of_study']; ?></td>
        <td><?php echo $row['email']; ?></td>
    </tr>
    <?php } ?>

</table>

<br>
<a href="index.php">Back to Form</a>

</body>
</html>
