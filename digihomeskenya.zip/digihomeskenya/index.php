<!DOCTYPE html>
<html>
<head>
    <title>Student Registration</title>
</head>
<body>

<h2>Student Registration Form</h2>

<form method="POST" action="save_student.php">
    <label>Student Name:</label><br>
    <input type="text" name="name" required><br><br>

    <label>Age:</label><br>
    <input type="number" name="age" required><br><br>

    <label>Course:</label><br>
    <input type="text" name="course" required><br><br>

    <label>Year of Study:</label><br>
    <select name="year" required>
        <option value="">-- Select Year --</option>
        <option value="1">Year 1</option>
        <option value="2">Year 2</option>
        <option value="3">Year 3</option>
        <option value="4">Year 4</option>
    </select>

<br><br>

    <label>Email:</label><br>
    <input type="email" name="email" required><br><br>

    <button type="submit">Submit</button>
</form>

<br>
<a href="view_students.php">View Students</a>

</body>
</html>
