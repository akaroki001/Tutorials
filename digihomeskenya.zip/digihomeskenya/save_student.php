<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "student_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database); // open the database

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$age = $_POST['age'];
$course = $_POST['course'];
$year = $_POST['year'];
$email = $_POST['email'];

// Insert data
$sql = "INSERT INTO students (name, age, course, year_of_study, email)
        VALUES ('$name', '$age', '$course', '$year', '$email')";

if ($conn->query($sql) === TRUE) {
    echo "Student registered successfully.<br>";
    echo "<a href='index.php'>Back to Form</a>";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
